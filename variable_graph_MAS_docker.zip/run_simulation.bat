@echo off
REM Script to run the Variable Graph MAS simulation in Docker (Windows)

set CONFIG_FILE=%1
set SIM_TIME=%2

if "%CONFIG_FILE%"=="" set CONFIG_FILE=easyTest.yml
if "%SIM_TIME%"=="" set SIM_TIME=100

echo Running simulation with config: %CONFIG_FILE% for %SIM_TIME% seconds
docker-compose run --rm variable_graph_mas python main_single_sim.py %CONFIG_FILE% %SIM_TIME%
