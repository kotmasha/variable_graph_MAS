#!/bin/bash
# Script to create a distributable zip package
# This script excludes .git directory and large binary files

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ZIP_NAME="variable_graph_MAS_docker_${TIMESTAMP}.zip"
SOURCE_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Creating distributable package: $ZIP_NAME"

# Create zip excluding unnecessary files
cd "$SOURCE_PATH"
zip -r "$ZIP_NAME" . \
    -x "*.git*" \
    -x "*output/*" \
    -x "*sims/*" \
    -x "*.mp4" \
    -x "*.avi" \
    -x "*__pycache__*" \
    -x "*.pyc" \
    -x "*create_package.sh" \
    -x "*create_package.ps1"

echo ""
echo "Package created successfully: $SOURCE_PATH/$ZIP_NAME"
echo ""
echo "File size: $(du -h "$ZIP_NAME" | cut -f1)"
echo ""
echo "Recipient instructions:"
echo "1. Unzip the file"
echo "2. Install Docker (if not already installed)"
echo "3. Open terminal in the extracted directory"
echo "4. Run: docker-compose build"
echo "5. Run: ./run_simulation.sh easyTest_docker.yml 100"
echo ""
echo "No Python or ffmpeg installation needed!"
