# Docker Setup for Variable Graph MAS

This Docker setup ensures the simulation runs without any ffmpeg installation or path issues.

## Prerequisites

- Docker installed ([Get Docker](https://docs.docker.com/get-docker/))
- Docker Compose installed (usually comes with Docker Desktop)

## Quick Start

### Option 1: Using Docker Compose (Recommended)

1. **Build the Docker image:**
   ```bash
   docker-compose build
   ```

2. **Run a simulation:**
   
   **Linux/Mac:**
   ```bash
   ./run_simulation.sh easyTest_docker.yml 100
   ```
   
   **Windows:**
   ```cmd
   run_simulation.bat easyTest_docker.yml 100
   ```

   Or directly:
   ```bash
   docker-compose run --rm variable_graph_mas python main_single_sim.py easyTest_docker.yml 100
   ```

3. **Output files** will be saved to the `output/` directory on your host machine.

### Option 2: Using Docker directly

1. **Build the image:**
   ```bash
   docker build -t variable_graph_mas .
   ```

2. **Run the simulation:**
   ```bash
   docker run --rm -v ${PWD}/output:/app/output variable_graph_mas python src/main_single_sim.py src/easyTest_docker.yml 100
   ```

## Configuration Files

For Docker usage, ensure your YAML config files use container-friendly paths:
- `workPath: '/app/output/'` instead of `~/sims/...`

Example config files:
- `src/easyTest_docker.yml` - Pre-configured for Docker

## Output

All generated files (videos, plots, data) will appear in:
- `./output/` - Main output directory
- `./sims/` - Additional simulation outputs

## Troubleshooting

### Permission Issues (Linux/Mac)
If you get permission errors on output files:
```bash
sudo chown -R $USER:$USER output/ sims/
```

### No space left on device
Clean up old Docker images:
```bash
docker system prune -a
```

### Viewing output videos
The generated `.mp4` files will be in the `output/` directory and can be played with any video player (VLC, Windows Media Player, QuickTime, etc.).

## Interactive Mode

To explore the container interactively:
```bash
docker-compose run --rm variable_graph_mas bash
```

Then inside the container:
```bash
cd src
python main_single_sim.py easyTest_docker.yml 100
```

## What's Included

The Docker image includes:
- Python 3.10
- ffmpeg (system package)
- All Python dependencies:
  - numpy, matplotlib, scipy
  - shapely, qpsolvers, quadprog
  - PyYAML, descartes
  - ffmpeg-python

## Customizing

To modify simulations:
1. Edit configuration files in `src/*.yml`
2. Ensure `workPath` points to `/app/output/` for Docker
3. Run the simulation using the commands above

## Distribution

To share this project:
1. Zip the entire directory: `variable_graph_MAS.zip`
2. Recipient just needs to:
   - Unzip the file
   - Have Docker installed
   - Run `docker-compose build`
   - Run `./run_simulation.sh` (or `.bat` on Windows)

No Python installation, ffmpeg setup, or dependency management required!
