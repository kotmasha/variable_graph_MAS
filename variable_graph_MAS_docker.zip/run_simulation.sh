#!/bin/bash
# Script to run the Variable Graph MAS simulation in Docker

CONFIG_FILE=${1:-easyTest.yml}
SIM_TIME=${2:-100}

echo "Running simulation with config: $CONFIG_FILE for $SIM_TIME seconds"
docker-compose run --rm variable_graph_mas python main_single_sim.py $CONFIG_FILE $SIM_TIME
