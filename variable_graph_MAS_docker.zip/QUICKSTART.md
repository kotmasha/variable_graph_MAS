# 🚀 Quick Start Guide

## For Recipients

You've received this package to run the Variable Graph MAS simulation. **No Python installation or ffmpeg setup required!**

### Step 1: Install Docker

If you don't have Docker installed:
- **Windows/Mac**: Download [Docker Desktop](https://www.docker.com/products/docker-desktop)
- **Linux**: Follow [Docker Engine installation](https://docs.docker.com/engine/install/)

### Step 2: Extract the Package

Unzip the file to any directory on your computer.

### Step 3: Build the Docker Image

Open a terminal/command prompt in the extracted directory and run:

```bash
docker-compose build
```

This will take a few minutes the first time (downloads Python, ffmpeg, and all dependencies).

### Step 4: Run a Simulation

**Windows:**
```cmd
run_simulation.bat easyTest_docker.yml 100
```

**Linux/Mac:**
```bash
chmod +x run_simulation.sh
./run_simulation.sh easyTest_docker.yml 100
```

Where:
- `easyTest_docker.yml` is the configuration file
- `100` is the simulation time in seconds

### Step 5: View Results

Output files (videos, plots) will be saved in the `output/` directory.

## Common Issues

### "Docker is not running"
- Start Docker Desktop (Windows/Mac)
- Start Docker service (Linux): `sudo systemctl start docker`

### Permission errors (Linux)
```bash
sudo usermod -aG docker $USER
```
Then log out and log back in.

### Can't see output files
Check the `output/` directory in the same folder where you ran the simulation.

## Available Config Files

- `easyTest_docker.yml` - 11 agents with obstacles (Recommended for testing)
- `randomSpawnNoObs.yml` - Random spawn without obstacles
- `edgeCases.yml` - Edge case scenarios
- `agentsWithObsnPos.yml` - Agents with observation positions

To use different configs, just replace the filename in the run command.

## Need Help?

See `DOCKER_README.md` for detailed documentation.
See original `README.md` for theory and algorithm details.

---

**That's it!** You can now run complex multi-agent simulations without worrying about dependencies, paths, or ffmpeg installation issues. 🎉
